#pragma once
#include "GameObject.h"
class Moneda :
    public GameObject
{
};

