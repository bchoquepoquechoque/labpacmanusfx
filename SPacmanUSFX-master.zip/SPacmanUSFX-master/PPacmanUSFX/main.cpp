#include <iostream>
#include "GameManager.h"

using namespace std;


int main(int argc, char* argv[]) {
    GameManager theApp;

    return theApp.onExecute();
}